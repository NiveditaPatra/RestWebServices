package dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import model.Employee;

public class EmployeeDAO {

	private static final Map<Integer,Employee> empMap=new HashMap<Integer, Employee>();
	
	static{
		initEmps();
	}
	public static void initEmps(){
		Employee emp1=new Employee(101, "Smith", "Clerk");
		Employee emp2=new Employee(102, "Bob", "SalesMan");
		Employee emp3=new Employee(103, "Ravi", "Manager");
		empMap.put(emp1.getEmpNo(),emp1);
		empMap.put(emp2.getEmpNo(),emp2);
		empMap.put(emp2.getEmpNo(),emp3);
		
	}
	public static Employee getEmployee(int empNo){
		return empMap.get(empNo);
	}
	public static Employee addEmployee(Employee emp){
		empMap.put(emp.getEmpNo(), emp);
		return emp;
	}
	public static Employee updateEmployee(Employee emp){
		empMap.put(emp.getEmpNo(), emp);
		return emp;
	}
	public static Employee deleteEmployee(int empNo){
		return empMap.remove(empNo);
	}
	
	public static List<Employee> getAllEmployees(){
		Collection<Employee> c=empMap.values();
		List<Employee> list=new ArrayList<Employee>();
		list.addAll(c);
		return list;
	}

    
}
